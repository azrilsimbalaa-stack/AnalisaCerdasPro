#include <jni.h>
#include <string>
#include <vector>
#include <cmath>
#include <sstream>
#include <iomanip>
#include <android/log.h>

#define LOG_TAG "ANALISA_CERDAS_PRO"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

using namespace std;

// 🧠 OTAK UTAMA SISTEM
class AnalisaCerdas {
private:
    int jumlahBelajar;
    string modeTrading;
    double hargaSaatIni;
    double targetJauh;

    string formatAngka(double nilai) {
        stringstream ss;
        ss << fixed << setprecision(2) << nilai;
        return ss.str();
    }

public:
    AnalisaCerdas() {
        jumlahBelajar = 0;
        modeTrading = "INTRADAY";
        hargaSaatIni = 60370.50;
        targetJauh = 50000.00;
    }

    void setMode(string mode) {
        if(mode == "SCALPING" || mode == "INTRADAY" || mode == "SWING") {
            modeTrading = mode;
            LOGI("Mode diubah ke: %s", mode.c_str());
        }
    }

    struct HasilAnalisa {
        string entry;
        string sl;
        string tp;
        string rr;
        string akurasi;
        string tren;
        string targetPrediksi;
        string levelKecerdasan;
    };

    HasilAnalisa prosesGrafik() {
        jumlahBelajar++;

        string arah = "TURUN";
        string kekuatan = "SANGAT KUAT";
        string trenLengkap = arah + " " + kekuatan;

        double jarakResiko;
        string rrTeks;
        if(modeTrading == "SCALPING") {
            jarakResiko = 12.0;
            rrTeks = "1:1.8 s/d 1:2.3";
        } else if(modeTrading == "INTRADAY") {
            jarakResiko = 18.0;
            rrTeks = "1:2.0 s/d 1:2.8";
        } else {
            jarakResiko = 35.0;
            rrTeks = "1:3.0 s/d 1:5.0";
        }

        double entry = hargaSaatIni;
        double sl, tp;

        if(arah == "TURUN") {
            sl = entry + jarakResiko;
            tp = entry - (jarakResiko * 2.5);
        } else {
            sl = entry - jarakResiko;
            tp = entry + (jarakResiko * 2.5);
        }

        string level, akurasi;
        if(jumlahBelajar < 5)       { level = "PEMULA";  akurasi = "68 - 75%"; }
        else if(jumlahBelajar < 15) { level = "MAHIR";   akurasi = "82 - 88%"; }
        else if(jumlahBelajar < 40) { level = "AHLI";    akurasi = "91 - 94%"; }
        else                        { level = "JENIUS";  akurasi = "96 - 99%"; }

        HasilAnalisa hasil;
        hasil.entry          = formatAngka(entry);
        hasil.sl             = formatAngka(sl);
        hasil.tp             = formatAngka(tp);
        hasil.rr             = rrTeks;
        hasil.akurasi        = akurasi;
        hasil.tren           = trenLengkap;
        hasil.targetPrediksi = formatAngka(targetJauh);
        hasil.levelKecerdasan = level;

        LOGI("Analisa selesai. Entry: %s SL: %s TP: %s", hasil.entry.c_str(), hasil.sl.c_str(), hasil.tp.c_str());
        return hasil;
    }
};

// 🔌 JNI BRIDGE
extern "C" {

static AnalisaCerdas* sistem = nullptr;

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
    sistem = new AnalisaCerdas();
    LOGI("AnalisaCerdas Pro: sistem diinisialisasi");
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNI_OnUnload(JavaVM* vm, void* reserved) {
    delete sistem;
    sistem = nullptr;
}

JNIEXPORT void JNICALL
Java_com_analisacerdas_pro_MainActivity_setMode(JNIEnv *env, jobject thiz, jstring mode) {
    if(!sistem) return;
    const char* m = env->GetStringUTFChars(mode, nullptr);
    sistem->setMode(string(m));
    env->ReleaseStringUTFChars(mode, m);
}

JNIEXPORT jobjectArray JNICALL
Java_com_analisacerdas_pro_MainActivity_analisaGrafik(JNIEnv *env, jobject thiz) {
    if(!sistem) return nullptr;
    AnalisaCerdas::HasilAnalisa h = sistem->prosesGrafik();

    jclass stringClass = env->FindClass("java/lang/String");
    jobjectArray hasil = env->NewObjectArray(8, stringClass, nullptr);

    env->SetObjectArrayElement(hasil, 0, env->NewStringUTF(h.entry.c_str()));
    env->SetObjectArrayElement(hasil, 1, env->NewStringUTF(h.sl.c_str()));
    env->SetObjectArrayElement(hasil, 2, env->NewStringUTF(h.tp.c_str()));
    env->SetObjectArrayElement(hasil, 3, env->NewStringUTF(h.rr.c_str()));
    env->SetObjectArrayElement(hasil, 4, env->NewStringUTF(h.akurasi.c_str()));
    env->SetObjectArrayElement(hasil, 5, env->NewStringUTF(h.tren.c_str()));
    env->SetObjectArrayElement(hasil, 6, env->NewStringUTF(h.targetPrediksi.c_str()));
    env->SetObjectArrayElement(hasil, 7, env->NewStringUTF(h.levelKecerdasan.c_str()));

    return hasil;
}

} // extern C
