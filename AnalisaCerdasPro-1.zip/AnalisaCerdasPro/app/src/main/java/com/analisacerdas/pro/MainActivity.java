package com.analisacerdas.pro;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    static {
        System.loadLibrary("analisacerdas");
    }

    private TextView tvEntry, tvSL, tvTP, tvRR, tvAkurasi, tvTren, tvTarget, tvLevel;
    private Button btnScalping, btnIntraday, btnSwing;
    private View loadingView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();

        // Default mode INTRADAY
        setModeActive("INTRADAY");
        setMode("INTRADAY");

        // Analisa otomatis saat buka
        prosesAnalisa();

        // Tombol mode
        btnScalping.setOnClickListener(v -> { setModeActive("SCALPING"); setMode("SCALPING"); prosesAnalisa(); });
        btnIntraday.setOnClickListener(v -> { setModeActive("INTRADAY"); setMode("INTRADAY"); prosesAnalisa(); });
        btnSwing.setOnClickListener(v    -> { setModeActive("SWING");    setMode("SWING");    prosesAnalisa(); });
    }

    private void initView() {
        tvEntry   = findViewById(R.id.tv_entry);
        tvSL      = findViewById(R.id.tv_sl);
        tvTP      = findViewById(R.id.tv_tp);
        tvRR      = findViewById(R.id.tv_rr);
        tvAkurasi = findViewById(R.id.tv_akurasi);
        tvTren    = findViewById(R.id.tv_tren);
        tvTarget  = findViewById(R.id.tv_target);
        tvLevel   = findViewById(R.id.tv_level);

        btnScalping = findViewById(R.id.btn_scalping);
        btnIntraday = findViewById(R.id.btn_intraday);
        btnSwing    = findViewById(R.id.btn_swing);

        loadingView = findViewById(R.id.loading_layout);
    }

    private void prosesAnalisa() {
        loadingView.setVisibility(View.VISIBLE);

        new android.os.Handler().postDelayed(() -> {
            String[] data = analisaGrafik();

            if (data != null && data.length >= 8) {
                tvEntry.setText(data[0]);
                tvSL.setText(data[1]);
                tvTP.setText(data[2]);
                tvRR.setText(data[3]);
                tvAkurasi.setText(data[4]);
                tvTren.setText(data[5]);
                tvTarget.setText(data[6]);
                tvLevel.setText("LEVEL: " + data[7]);
            } else {
                Toast.makeText(this, "Gagal memproses data", Toast.LENGTH_SHORT).show();
            }

            loadingView.setVisibility(View.GONE);
        }, 1500);
    }

    private void setModeActive(String mode) {
        btnScalping.setSelected(false);
        btnIntraday.setSelected(false);
        btnSwing.setSelected(false);

        if (mode.equals("SCALPING"))   btnScalping.setSelected(true);
        else if (mode.equals("INTRADAY")) btnIntraday.setSelected(true);
        else if (mode.equals("SWING"))    btnSwing.setSelected(true);
    }

    public native void setMode(String mode);
    public native String[] analisaGrafik();
}
