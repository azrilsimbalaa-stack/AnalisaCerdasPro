-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class com.analisacerdas.pro.** { *; }
